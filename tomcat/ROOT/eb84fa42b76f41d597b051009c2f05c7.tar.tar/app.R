library(shiny)
library(shinyalert)
library(shinyjs)
library(sp)
library(stringr)
library(raster)
library(rgdal)
library(dplyr)
library(ggplot2)
library(reshape2)
library(leaflet)
library(leafem)
library(leaflet.extras)
library(RColorBrewer)
library(proj4)
library(DT)
library(htmltools)
geoserver.url <- 'http://dss.icem.com.au:9307/geoserver/'
mmradm.ws <- 'mmr_admin:'
dir.data <- paste0(getSrcDirectory(function(dummy) {dummy}),'/data/')
#colors <- c('Very Low'='#FFFEC4', 'Low'='#FFFF99', 'Medium'='#FFCC00', 'High'='#FF9900', 'Very High'='#FF6600')
colors <- c('VL'='#FFFEC4', 'L'='#FFFF99', 'M'='#FFCC00', 'H'='#FF9900', 'VH'='#FF6600')

ui = fluidPage(title = "Decision Support System for Risk Informed Agricultural Investment Planning", id = 'container', tags$style("{max-width: 1200px;}"),
               useShinyalert(),
               useShinyjs(),
               tags$head(tags$link(rel = "stylesheet", type = "text/css", href = "styles.css"),
                         tags$link(rel = "stylesheet", type = "text/css", href = "wowslider.css"),
                         tags$script(type = "text/javascript", src = "busy.js"),
                         tags$script(src = "leaflet-side-by-side.js"),
                         tags$script(src = "leaflet.wms.js"),
                         tags$script(src = "L.Control.ZoomMin.js"),
                         tags$script(src = 'wowslider.js'),
                         tags$script(src = 'ta9307.js')),
               div(id = 'wrapper',
                   div(titlePanel(includeHTML("www/header.html"), windowTitle = "Decision Support System for Risk Informed Agricultural Investment Planning")),
                   tabsetPanel(id = "navpage",
                               tabPanel('Risk screening - 3 options', fluidPage(
                                 #fluidRow(h3('Draw area of interest on the map to start screening process...')),
                                 fluidRow(column(6, 
                                                 # fluidRow(h4('Select admin area from dropdown or navigate on map to project site:')),
                                                 # fluidRow(column(4,selectInput(inputId = "rs.adm1", label = "State/ Region", choices = c("State/ Region" = ""))),
                                                 #          column(4,selectInput(inputId = "rs.adm2", label = "District", choices = c("District" = ""))),
                                                 #          column(4,selectInput(inputId = "rs.adm3", label = "Township", choices = c("Township" = "")))),
                                                 # fluidRow(hr()),
                                                 fluidRow(actionButton("rs_start", "Start screening 3 options"))),
                                          column(6, tags$div(
                                            id = "load_icon",
                                            class = "busy",
                                            p('Busy ... '),
                                            img(src = "loader.gif"),
                                            align = 'center',
                                            style = 'margin-top: 100px;'
                                          ))),
                                 fluidRow(hr(width = '100%')),
                                 uiOutput('risk_scan'))
                               ),
                               tabPanel('Risk screening - 5 options', fluidPage(
                                 #fluidRow(h3('Draw area of interest on the map to start screening process...')),
                                 fluidRow(column(2, offset = 2,
                                                 # fluidRow(h4('Select admin area from dropdown or navigate on map to project site:')),
                                                 # fluidRow(column(4,selectInput(inputId = "rs.adm1", label = "State/ Region", choices = c("State/ Region" = ""))),
                                                 #          column(4,selectInput(inputId = "rs.adm2", label = "District", choices = c("District" = ""))),
                                                 #          column(4,selectInput(inputId = "rs.adm3", label = "Township", choices = c("Township" = "")))),
                                                 # fluidRow(hr()),
                                                 fluidRow(actionButton("rs_start5", "Start screening 5 options"))),
                                          column(6, tags$div(
                                            id = "load_icon",
                                            class = "busy",
                                            p('Busy ... '),
                                            img(src = "loader.gif"),
                                            align = 'center',
                                            style = 'margin-top: 100px;'
                                          ))),
                                 fluidRow(hr(width = '100%')),
                                 uiOutput('risk_scan5'))
                               ),
                               tabPanel('About',
                                        fluidPage(fluidRow(h4('Assessment matrix for development project')),
                                                  fluidRow(tags$img(src = "assessment_matrix/Slide1.jpg", width = "580px"), 
                                                           tags$img(src = "assessment_matrix/Slide2.jpg", width = "580px"))))
                   ),
                   absolutePanel(id = "logos", fixed = TRUE, draggable = FALSE, 
                                 top = "auto", left = 0, right = 0, bottom = 0, width = 1200, height = 60,
                                 fluidRow(
                                   column(3),
                                   column(1, a(href = "https://www.adb.org/", img(id = "logo_center", src = "img/adb.jpg", height=50, style = "margin-top: 10px;"), target="_blank")),
                                   column(3, a(href = "", img(id = "logo_center", src = "img/canada_aid.png", height=40, style = "margin-top: 20px;"), target="_blank")),
                                   column(2, a(href = "http://www.icem.com.au/", img(id = "logo_center", src = "img/ICEM_logo.jpg", height=60), target="_blank")),
                                   column(3)
                                 ))
               ))

server = function(input, output, session) {
  pr0 <- function(val) {
    if (exists(val)) {
      print(paste0(val, ': ',get(val)))
    } else {print(paste0(val, ': not exist'))}
  }
  
  setzoom <- function(boxx, mapw, maph){
    tmp <- floor(log(min(c(mapw/(boxx@xmax-boxx@xmin),maph/(boxx@ymax-boxx@ymin))))*2/log(2))
    return(tmp/2.0)
  }
  prjdr <- 1
  
  observeEvent(input$rs_start5, {
    #print(c(input$rs.scenario, input$rs.lifetime))
    prjdr <<- prjdr + 1
    output$risk_scan <- renderUI(p(paste0(input$rs.scenario, input$rs.lifetime)))
    hz_screening <<- data.frame(read.csv(paste0(dir.data,"hazard_lst.csv")))
    hz_max <- function(hz_lyr, hzgrid) {
      hzrast <- lapply(1:grid.num, function(ii){
        if (hzgrid=='') {
          print(paste0(dir.data, 'hazard_tiff/', hz_lyr, '/', hz_lyr, grid.included$boxid[ii], '.tif'))
          tmp_rast <- raster::raster(paste0(dir.data, 'hazard_tiff/', hz_lyr, '/', hz_lyr, grid.included$boxid[ii], '.tif'))
          tmp <- raster::extract(tmp_rast,project_drw, fun=max, na.rm=TRUE)
          return(tmp)
        } else {
          if (unlist(grid.included@data[hzgrid])[ii]>0){
            print(paste0(dir.data, 'hazard_tiff/', hz_lyr, '/', hz_lyr, grid.included$boxid[ii], '.tif'))
            tmp_rast <- raster::raster(paste0(dir.data, 'hazard_tiff/', hz_lyr, '/', hz_lyr, grid.included$boxid[ii], '.tif'))
            tmp <- raster::extract(tmp_rast,project_drw, fun=max, na.rm=TRUE)
            return(tmp)
          } else { return(-1) } }
      })
      return(max(unlist(hzrast)))
    }
    
    clsidx <- function(x, cls) {
      if (x > cls[length(cls)]) {return(length(cls)+1)
      } else { for (i in 1:length(cls)) {
        if (x <= cls[i]) {
          return(i)
          break }}
      }}
    hz_color <- c('#7FFFD4;', '#FFFEC4', '#FFFF99', '#FFCC00', '#FF9900', '#FF6600')
    hz_c5 <-               c('Very Low',    'Low',  'Medium',   'High',  'Very High')
    invest_color <- c('#AAFFAA', '#55FF55', '#00FF00', '#00CC00', '#009900')
    screening_stt <- c('green', 'yellow', 'red')
    
    f.cam <- function(rowlevel, collevel) {
      switch (rowlevel,
              switch(collevel, 1, 2, 2, 3, 4),
              switch(collevel, 2, 2, 3, 3, 4),
              switch(collevel, 2, 3, 3, 4, 5),
              switch(collevel, 2, 3, 4, 4, 5),
              switch(collevel, 3, 3, 4, 5, 5))
    }
    # f.impact <- function(exposure, sensitivity) {
    #   switch (exposure,
    #     ifelse((sensitivity == 0), 0, 1),
    #     ifelse((sensitivity == 0), 0, ifelse((sensitivity == 1), 1, 2)),
    #     ifelse((sensitivity == 0), 1, 2),
    #     ifelse((sensitivity == 0), 1, ifelse((sensitivity == 1), 2, 3)),
    #     ifelse((sensitivity == 0), 2, ifelse((sensitivity == 1), 3, 4))
    #   )}
    # f.vulnerability <- function(impact, adapcapacity) {
    #   switch (impact+1,
    #     1,
    #     ifelse((adapcapacity == 0), 2, 1),
    #     ifelse((adapcapacity == 2), 1, 2),
    #     ifelse((adapcapacity == 0), 3, 2),
    #     ifelse((adapcapacity == 2), 2, 3)
    #   )}
    txt_hz <- function(hzvalue, hzcls) {
      if (length(hzcls) == 1) {return(span(hz_c5[hzvalue], style = paste0("padding: .3em .5em; font-weight: bold; background-color: ", hz_color[hzvalue+1])))
      } else { if (hzvalue < hzcls[1]) {return(span('No hazard', style = paste0("padding: .3em .5em; font-weight: bold; background-color: ", hz_color[1])))
      } else { return(span(round(hzvalue, digits = 3), style = paste0("padding: .3em .5em; font-weight: bold; background-color: ", hz_color[clsidx(hzvalue, hzcls)])))}}
    }
    #hz_screening[, c('hz_max1', 'hz_max2', 'maxhz_cls', 'impact', 'vulnerability')] <<- NA
    hz_screening[, c('maxhz_cls', 'impact', 'vulnerability')] <<- NA
    risk_scan <- reactiveValues(risk_grid = list(), assessment = list())
    
    for (i in row.names(subset(hz_screening, hz_caption != ''))) {
      #hz_screening[i, 'hz_max1'] <<- hz_max(hz_screening[i,'hz_lyr'], toString(hz_screening[i,'grid_idx']))
      #hz_screening[i, 'hz_max2'] <<- ifelse((hz_screening[i,'pair_lyr']==''),-1, hz_max(hz_screening[i,'pair_lyr'], toString(hz_screening[i,'grid_idx'])))
      max_hz <- ifelse((hz_screening[i,'pair_caption'] ==''), hz_screening[i, 'hz_max1'], max(c(hz_screening[i, 'hz_max1'], hz_screening[i, 'hz_max2'])))
      if (hz_screening[i, 'hzcls'] == 'C5') {hz_screening[i, 'maxhz_cls'] <<- max_hz
      } else {
        hz_cls <- as.numeric(strsplit(toString(hz_screening[i, 'hzcls']),',')[[1]])
        hz_screening[i, 'maxhz_cls'] <<- clsidx(max_hz,hz_cls) - 1}
    }
    risk_scan$risk_grid <- lapply(row.names(subset(hz_screening, hz_caption != '')), function(i) {
      if (hz_screening[i, 'hzcls'] == 'C5') {hz_cls <- 1} else {hz_cls <- as.numeric(strsplit(toString(hz_screening[i, 'hzcls']),',')[[1]])}
      if (hz_screening[i, 'maxhz_cls'] > 0) {
        if (hz_screening[i,'pair_caption'] !='') {
          list(
            fluidRow(column(3, paste0(hz_screening[i, 'hazard_type'],': ')),
                     column(3, paste0(hz_screening[i,'legend_text'], ': '), br(),
                            paste0(hz_screening[i,'hz_caption'], ': '), txt_hz(hz_screening[i, 'hz_max1'], hz_cls), br(),
                            paste0(hz_screening[i,'pair_caption'], ': '), txt_hz(hz_screening[i, 'hz_max2'], hz_cls)),
                     column(1, radioButtons(inputId = paste0("c_r2invest", LETTERS[prjdr], i), label = NULL, 
                                            #choices = c('Very High'='5', 'High'='4', 'Medium'='3', 'Low'='2', 'Very Low'='1'), 
                                            choiceNames = lapply(5:1, function(i) {HTML(paste0('<span style="padding: .3em .1em; background-color:',hz_color[i+1],'; font-weight: bold;">', hz_c5[i],'</span>'))}),
                                            choiceValues = c(5:1),
                                            selected = character(0))),
                     column(1, conditionalPanel(condition = paste0("input.c_r2invest", LETTERS[prjdr], i, "!= null"), radioButtons(inputId = paste0("c_reduct", LETTERS[prjdr], i), label = NULL, 
                                                                                                                                   choiceNames = lapply(1:5, function(i) {HTML(paste0('<span style="padding: .3em .1em; background-color: ',invest_color[i],'; font-weight: bold;">', hz_c5[i],'</span>'))}),
                                                                                                                                   choiceValues = c(1:5),
                                                                                                                                   selected = character(0)))),
                     column(3, textAreaInput(inputId = paste0("txtinp", LETTERS[prjdr],i), label = NULL, width = '100%', height = '100%', placeholder = 'Comments')),
                     column(1, div(id= paste0("icon_", LETTERS[prjdr],i), icon('fas fa-circle', 'fa-4x'), style = "text-align: center; margin: auto; color: grey"))),
            fluidRow(hr(width = '80%')))
        } else {
          list(
            fluidRow(column(3, paste0(hz_screening[i, 'hazard_type'],': ')),
                     column(3, paste0(hz_screening[i,'legend_text'], ': '), br(),
                            paste0(hz_screening[i,'hz_caption'], ': '), txt_hz(hz_screening[i, 'hz_max1'], hz_cls)),
                     column(1, radioButtons(inputId = paste0("c_r2invest", LETTERS[prjdr], i), label = NULL, 
                                            #choices = c('Very High'='5', 'High'='4', 'Medium'='3', 'Low'='2', 'Very Low'='1'), 
                                            choiceNames = lapply(5:1, function(i) {HTML(paste0('<span style="padding: .3em .1em; background-color:',hz_color[i+1],'; font-weight: bold;">', hz_c5[i],'</span>'))}),
                                            choiceValues = c(5:1),                                            selected = character(0))),
                     column(1, conditionalPanel(condition = paste0("input.c_r2invest", LETTERS[prjdr], i, "!= null"), radioButtons(inputId = paste0("c_reduct", LETTERS[prjdr], i), label = NULL, 
                                                                                                                                   choiceNames = lapply(1:5, function(i) {HTML(paste0('<span style="padding: .3em .1em; background-color: ',invest_color[i],'; font-weight: bold;">', hz_c5[i],'</span>'))}),
                                                                                                                                   choiceValues = c(1:5),
                                                                                                                                   selected = character(0)))),
                     column(3, textAreaInput(inputId = paste0("txtinp", LETTERS[prjdr],i), label = NULL, width = '100%', height = '100%', placeholder = 'Comments')),
                     column(1, div(id= paste0("icon_", LETTERS[prjdr],i), icon('fas fa-circle', 'fa-4x'), style = "text-align: center; margin: auto; color: grey"))),
            fluidRow(hr(width = '80%')))
        } }
    })
    # lapply(1:5, function(i) {HTML(paste0('<p style="color:',hz_color[i],'; font-weight: bold;">', hz_c5[i],'</p>'))})
    risk_scan$assessment <- lapply(row.names(subset(hz_screening, hz_caption != '')), function(i) {
      if (hz_screening[i, 'maxhz_cls'] > 0) {
        observeEvent(c(input[[paste0("c_r2invest", LETTERS[prjdr], i)]], input[[paste0("c_reduct", LETTERS[prjdr],i)]]), {
          sensi_i <- -1
          adapcap_i <- -1
          sensi_i <- strtoi(input[[paste0("c_r2invest", LETTERS[prjdr],i)]])
          hz_screening[i, 'impact'] <<- f.cam(sensi_i, hz_screening[i, 'maxhz_cls'])
          if (sensi_i == 0) {
            hz_screening[i, 'vulnerability'] <<- f.vulnerability(hz_screening[i, 'impact'], 0)
            html(paste0("icon_", LETTERS[prjdr],i), paste0('<div style="text-align: center; margin: auto; color: ', screening_stt[hz_screening[i, 'vulnerability']],'"><i class="fa fa-fas fa-circle fa-4x"></i></div>'))
          } else {
            if (is.null(input[[paste0("c_reduct", LETTERS[prjdr],i)]])) {
              hz_screening[i, 'vulnerability'] <<- NA
              html(paste0("icon_", LETTERS[prjdr],i), '<div style="text-align: center; margin: auto; color: grey"><i class="fa fa-fas fa-circle fa-4x"></i></div>')
            } else {
              adapcap_i <- strtoi(input[[paste0("c_reduct", LETTERS[prjdr],i)]])
              hz_screening[i, 'vulnerability'] <<- f.cam(6-adapcap_i, hz_screening[i, 'impact'])
              html(paste0("icon_", LETTERS[prjdr],i), paste0('<div style="text-align: center; margin: auto; background-color: #008FFF; color: ', hz_color[hz_screening[i, 'vulnerability']+1],'"><b>',hz_c5[hz_screening[i, 'vulnerability']],'</b><br><i class="fa fa-fas fa-circle fa-4x"></i></div>'))
            }
          }
          print(c(hz_c5[hz_screening[i, 'maxhz_cls']], hz_c5[sensi_i], hz_c5[hz_screening[i, 'impact']], hz_c5[adapcap_i], hz_screening[i, 'vulnerability']))
        })
        
        # observeEvent(input[[paste0("c_r2invest", LETTERS[prjdr], i)]], {
        #   sensi_i <- strtoi(input[[paste0("c_r2invest", LETTERS[prjdr],i)]])
        #   alert(f.cam(hz_screening[i, 'maxhz_cls'], sensi_i))
        # })
      }
    })
    
    # risk_scan$risk_grid <- append(list(fluidRow(column(3, div('Hazard name', style="text-align: center; font-weight: bold; margin-bottom: 40px;")), 
    #                                             column(3, div('Present of hazard', style="text-align: center; font-weight: bold;")), 
    #                                             column(1, div('Risk to investment', style="text-align: center; font-weight: bold;")), 
    #                                             column(1, div('Risk reduction', style="text-align: center; font-weight: bold;")), 
    #                                             column(3, div('Comments', style="text-align: center; font-weight: bold;")), 
    #                                             column(1, div('Screening status', style="text-align: center; font-weight: bold;")))), risk_scan$risk_grid)
    risk_scan$risk_grid <- append(list(fluidRow(column(3, div('Hazard name', style="text-align: center; font-weight: bold; margin-bottom: 40px;")), 
                                                column(3, div('Present of hazard', style="text-align: center; font-weight: bold;")), 
                                                column(1, div('Risk to investment', style="text-align: center; font-weight: bold;")), 
                                                column(1, div('Risk reduction', style="text-align: center; font-weight: bold;")), 
                                                column(3, div('Comments', style="text-align: center; font-weight: bold;")), 
                                                column(1, div('Screening status', style="text-align: center; font-weight: bold;")))), 
                                  list(wellPanel(id = "risk_table",
                                                 style = "background-color: #FFFFFF; border: 1px; margin: 0px; height: 50vh; width: 1200px; overflow-y: auto;", risk_scan$risk_grid)))
    output$risk_scan5 <- renderUI({do.call(list, risk_scan$risk_grid)})
    #shinyjs::runjs("window.scrollBy(0, window.innerHeight);")
    print(Sys.time())
  })
  fixedRow()
  observeEvent(input$rs_start, {
    #print(c(input$rs.scenario, input$rs.lifetime))
    prjdr <<- prjdr + 1
    output$risk_scan5 <- renderUI(p(paste0(input$rs.scenario, input$rs.lifetime)))
    hz_screening <<- data.frame(read.csv(paste0(dir.data,"hazard_lst.csv")))
    
    clsidx <- function(x, cls) {
      if (x > cls[length(cls)]) {return(length(cls)+1)
      } else { for (i in 1:length(cls)) {
        if (x <= cls[i]) {
          return(i)
          break }}
      }}
    hz_color <- c('#7FFFD4;', '#00FFFF;', '#1E90FF;', '#FFD700;', '#FFA500;', '#FF0000;')
    hz_c5 <- c('Very Low', 'Low', 'Medium', 'High', 'Very High')
    screening_stt <- c('green', 'yellow', 'red')
    f.impact <- function(exposure, sensitivity) {
      switch (exposure,
              ifelse((sensitivity == 0), 0, 1),
              ifelse((sensitivity == 0), 0, ifelse((sensitivity == 1), 1, 2)),
              ifelse((sensitivity == 0), 1, 2),
              ifelse((sensitivity == 0), 1, ifelse((sensitivity == 1), 2, 3)),
              ifelse((sensitivity == 0), 2, ifelse((sensitivity == 1), 3, 4))
      )}
    f.vulnerability <- function(impact, adapcapacity) {
      switch (impact+1,
              1,
              ifelse((adapcapacity == 0), 2, 1),
              ifelse((adapcapacity == 2), 1, 2),
              ifelse((adapcapacity == 0), 3, 2),
              ifelse((adapcapacity == 2), 2, 3)
      )}
    txt_hz <- function(hzvalue, hzcls) {
      if (length(hzcls) == 1) {return(span(hz_c5[hzvalue], style = paste0("padding: .3em .5em; font-weight: bold; background-color: ", hz_color[hzvalue+1])))
      } else { if (hzvalue < hzcls[1]) {return(span('No hazard', style = paste0("padding: .3em .5em; font-weight: bold; background-color: ", hz_color[1])))
      } else { return(span(round(hzvalue, digits = 3), style = paste0("padding: .3em .5em; font-weight: bold; background-color: ", hz_color[clsidx(hzvalue, hzcls)])))}}
    }
    #hz_screening[, c('hz_max1', 'hz_max2', 'maxhz_cls', 'impact', 'vulnerability')] <<- NA
    hz_screening[, c('maxhz_cls', 'impact', 'vulnerability')] <<- NA
    risk_scan <- reactiveValues(risk_grid = list(), assessment = list())
    
    for (i in row.names(subset(hz_screening, hz_caption != ''))) {
      #hz_screening[i, 'hz_max1'] <<- hz_max(hz_screening[i,'hz_lyr'], toString(hz_screening[i,'grid_idx']))
      #hz_screening[i, 'hz_max2'] <<- ifelse((hz_screening[i,'pair_lyr']==''),-1, hz_max(hz_screening[i,'pair_lyr'], toString(hz_screening[i,'grid_idx'])))
      max_hz <- ifelse((hz_screening[i,'pair_caption'] ==''), hz_screening[i, 'hz_max1'], max(c(hz_screening[i, 'hz_max1'], hz_screening[i, 'hz_max2'])))
      if (hz_screening[i, 'hzcls'] == 'C5') {hz_screening[i, 'maxhz_cls'] <<- max_hz
      } else {
        hz_cls <- as.numeric(strsplit(toString(hz_screening[i, 'hzcls']),',')[[1]])
        hz_screening[i, 'maxhz_cls'] <<- clsidx(max_hz,hz_cls) - 1}
    }
    risk_scan$risk_grid <- lapply(row.names(subset(hz_screening, hz_caption != '')), function(i) {
      if (hz_screening[i, 'hzcls'] == 'C5') {hz_cls <- 1} else {hz_cls <- as.numeric(strsplit(toString(hz_screening[i, 'hzcls']),',')[[1]])}
      if (hz_screening[i, 'maxhz_cls'] > 0) {
        if (hz_screening[i,'pair_caption'] !='') {
          list(
            fluidRow(column(3, paste0(hz_screening[i, 'hazard_type'],': ')),
                     column(3, paste0(hz_screening[i,'legend_text'], ': '), br(),
                            paste0(hz_screening[i,'hz_caption'], ': '), txt_hz(hz_screening[i, 'hz_max1'], hz_cls), br(),
                            paste0(hz_screening[i,'pair_caption'], ': '), txt_hz(hz_screening[i, 'hz_max2'], hz_cls)),
                     column(1, radioButtons(inputId = paste0("c_r2invest", LETTERS[prjdr], i), label = NULL, choices = c('High'='2', 'Low'='1', 'None'='0'), selected = character(0))),
                     column(1, conditionalPanel(condition = paste0("input.c_r2invest", LETTERS[prjdr], i, "=='2' ||", "input.c_r2invest", LETTERS[prjdr], i, "=='1'"), radioButtons(inputId = paste0("c_reduct", LETTERS[prjdr], i), label = NULL, choices = c('None'='0', 'Low'='1', 'High'='2'), selected = character(0)))),
                     column(3, textAreaInput(inputId = paste0("txtinp", LETTERS[prjdr],i), label = NULL, width = '100%', height = '100%', placeholder = 'Comments')),
                     column(1, div(id= paste0("icon_", LETTERS[prjdr],i), icon('fas fa-circle', 'fa-4x'), style = "text-align: center; margin: auto; color: grey"))),
            fluidRow(hr(width = '80%')))
        } else {
          list(
            fluidRow(column(3, paste0(hz_screening[i, 'hazard_type'],': ')),
                     column(3, paste0(hz_screening[i,'legend_text'], ': '), br(),
                            paste0(hz_screening[i,'hz_caption'], ': '), txt_hz(hz_screening[i, 'hz_max1'], hz_cls)),
                     column(1, radioButtons(inputId = paste0("c_r2invest", LETTERS[prjdr], i), label = NULL, choices = c('High'='2', 'Low'='1', 'None'='0'), selected = character(0))),
                     column(1, conditionalPanel(condition = paste0("input.c_r2invest", LETTERS[prjdr], i, "=='2' ||", "input.c_r2invest", LETTERS[prjdr], i, "=='1'"), radioButtons(inputId = paste0("c_reduct", LETTERS[prjdr], i), label = NULL, choices = c('None'='0', 'Low'='1', 'High'='2'), selected = character(0)))),
                     column(3, textAreaInput(inputId = paste0("txtinp", LETTERS[prjdr],i), label = NULL, width = '100%', height = '100%', placeholder = 'Comments')),
                     column(1, div(id= paste0("icon_", LETTERS[prjdr],i), icon('fas fa-circle', 'fa-4x'), style = "text-align: center; margin: auto; color: grey"))),
            fluidRow(hr(width = '80%')))
        } }
    })
    
    risk_scan$assessment <- lapply(row.names(subset(hz_screening, hz_caption != '')), function(i) {
      if (hz_screening[i, 'maxhz_cls'] > 0) {
        observeEvent(c(input[[paste0("c_r2invest", LETTERS[prjdr], i)]], input[[paste0("c_reduct", LETTERS[prjdr],i)]]), {
          sensi_i <- -1
          adapcap_i <- -1
          sensi_i <- strtoi(input[[paste0("c_r2invest", LETTERS[prjdr],i)]])
          hz_screening[i, 'impact'] <<- f.impact(hz_screening[i, 'maxhz_cls'], sensi_i)
          if (sensi_i == 0) {
            hz_screening[i, 'vulnerability'] <<- f.vulnerability(hz_screening[i, 'impact'], 0)
            html(paste0("icon_", LETTERS[prjdr],i), paste0('<div style="text-align: center; margin: auto; color: ', screening_stt[hz_screening[i, 'vulnerability']],'"><i class="fa fa-fas fa-circle fa-4x"></i></div>'))
          } else {
            if (is.null(input[[paste0("c_reduct", LETTERS[prjdr],i)]])) {
              hz_screening[i, 'vulnerability'] <<- NA
              html(paste0("icon_", LETTERS[prjdr],i), '<div style="text-align: center; margin: auto; color: grey"><i class="fa fa-fas fa-circle fa-4x"></i></div>')
            } else {
              adapcap_i <- strtoi(input[[paste0("c_reduct", LETTERS[prjdr],i)]])
              hz_screening[i, 'vulnerability'] <<- f.vulnerability(hz_screening[i, 'impact'], adapcap_i)
              print(hz_screening[i, 'vulnerability'])
              html(paste0("icon_", LETTERS[prjdr],i), paste0('<div style="text-align: center; margin: auto; color: ', screening_stt[hz_screening[i, 'vulnerability']],'"><i class="fa fa-fas fa-circle fa-4x"></i></div>'))
            }
          }
          print(hz_screening[i, 'maxhz_cls'])
          print(hz_screening[i, 'impact'])
          print(c(sensi_i, adapcap_i))
        })  }
    })
    
    risk_scan$risk_grid <- append(list(fluidRow(column(3, div('Hazard name', style="text-align: center; font-weight: bold; margin-bottom: 40px;")), 
                                                column(3, div('Present of hazard', style="text-align: center; font-weight: bold;")), 
                                                column(1, div('Risk to investment', style="text-align: center; font-weight: bold;")), 
                                                column(1, div('Risk reduction', style="text-align: center; font-weight: bold;")), 
                                                column(3, div('Comments', style="text-align: center; font-weight: bold;")), 
                                                column(1, div('Screening status', style="text-align: center; font-weight: bold;")))), risk_scan$risk_grid)
    output$risk_scan <- renderUI({do.call(list, risk_scan$risk_grid)})
    shinyjs::runjs("window.scrollBy(0, window.innerHeight);")
    print(Sys.time())
  })
}

shinyApp(ui, server)
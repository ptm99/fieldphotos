setInterval(function(){
    if ($('html').attr('class')=='shiny-busy') {
        setTimeout(function() {
            if ($('html').attr('class')=='shiny-busy') {
                $('div.busy').show()
            }
        }, 10)
    } else {
        $('div.busy').hide()
    }
}, 0)
